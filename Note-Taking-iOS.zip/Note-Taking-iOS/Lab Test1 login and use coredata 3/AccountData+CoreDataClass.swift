//
//  AccountData+CoreDataClass.swift
//  Lab Test1 login and use coredata
//
//  Created by Benjamin Park on 11/16/16.
//  Copyright © 2016 Benjamin Park. All rights reserved.
//

import Foundation
import CoreData

/*@objc(AccountData)
public class AccountData: NSManagedObject {

}*/
