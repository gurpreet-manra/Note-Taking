//
//  AccountData+CoreDataProperties.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import Foundation
import CoreData

@objc(AccountData)
public class AccountData: NSManagedObject {
    



    @nonobjc public class func fetchRequest() -> NSFetchRequest<AccountData> {
        return NSFetchRequest<AccountData>(entityName: "Account");
    }

   
    @NSManaged public var uid: Double
    @NSManaged public var user_id: String?
   

}
