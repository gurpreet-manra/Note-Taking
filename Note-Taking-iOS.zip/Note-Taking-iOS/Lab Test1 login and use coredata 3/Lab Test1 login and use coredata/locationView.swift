//
//  locationView.swift
//  Lab Test1 login and use coredata
//
//  Created by Gurpreet Verma on 2017-11-30.
//  Copyright © 2017 Benjamin Park. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class locationView: UIViewController , CLLocationManagerDelegate {
    
    @IBOutlet weak var txtDesc: UITextView!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var locView: MKMapView!
    
    var itemInfo : MemoryInfo!
    
    var form : FormMemory_ViewController!

    var lati:Double = 0.0
    var longi:Double = 0.0
  let manager = CLLocationManager()
    
func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    let location = locations[0]
    
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
        let mylocation: CLLocationCoordinate2D = CLLocationCoordinate2DMake(lati, longi)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(mylocation, span)
        locView.setRegion(region, animated: true)
    let annotaion = MKPointAnnotation()
    
   annotaion.coordinate = mylocation
    annotaion.title = itemInfo.title!
    annotaion.subtitle = String(describing: mylocation)
    locView.addAnnotation(annotaion)
       self.locView.showsUserLocation = true
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    manager.delegate = self
      manager.desiredAccuracy = kCLLocationAccuracyBest
      manager.requestWhenInUseAuthorization()
       manager.startUpdatingLocation()
      lblTitle.text = itemInfo.title
        txtDesc.text = itemInfo.desc
        var key = itemInfo.title!
        if let loadMap = UserDefaults.standard.value(forKey: key) as? [Double] {
            
             lati = loadMap[0]
             longi = loadMap[1]
            
            
            
        }
      //  let loc = CLLocation(coder: itemInfo.loc!)
        //print(loc)
     /*
        print(itemInfo.lati)
        print("hello")
        print(itemInfo.title)
        let la = (itemInfo.lati!)
        let lo = (itemInfo.longi!)
       
       
        let lati =  CLLocationDegrees(la)
         print("hello2")
        print(lati)
        let longi = CLLocationDegrees(lo)
        
       let span:MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
        let mylocation: CLLocationCoordinate2D = CLLocationCoordinate2DMake(lati, longi)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(mylocation, span)
        locView.setRegion(region, animated: true)
        self.locView.showsUserLocation = true*/
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }
    
    
    
}
