//
//  SingletonManager.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import Foundation

protocol Initializable: class { init() }

class CoreManager<T> {
    
    private var instances = [String: Initializable]()
    
    func singletonInstance<T: Initializable>(_ ty: T.Type = T.self) -> T {
        let name = NSStringFromClass(ty)
        if let o = (instances[name] as? T) {
            return o
        }
        let o = ty.init()
        instances[name] = o
        return o
    }
}
