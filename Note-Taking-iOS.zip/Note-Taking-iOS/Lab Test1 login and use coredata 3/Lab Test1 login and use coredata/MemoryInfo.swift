//
//  ItemInfoCell.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit


class MemoryInfo: NSObject {
    
    
    var id : Double
    var objID : NSObject?
    var title : String?             // Title
    var desc : String?              // Desc
    var date : Date?                // Reg Date
    //var img : UIImage?            // Character Image
    var imgSrc : Data?
    var check : Bool = false        // Check flag
  
   
    
    // contstructor
    init(_ id:Double, title:String?, image:Data?) {
        self.id = id
        self.title = title
       
   
        self.date = Date()
        self.imgSrc = image
    }
    init(_ id:Double) {
        self.id = id
       
        self.date = Date()
    }
}
