//
//  MemoriesViewController.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit
import CoreData

class Main_TableViewController: UITableViewController {
    
    var managedContext : NSManagedObjectContext?
    
    var menuItems : NSMutableArray = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         LoadDatas()
        
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func LoadDatas() {
        
        menuItems.removeAllObjects()
        
        let results = CoreDataMemoryManager.FetchAll()
        print("total : \(results.count )");
        
        if results.count > 0 {
            for result in results {

                let newInfo = MemoryInfo(result.id)
                newInfo.objID = result.objectID
                newInfo.title = result.name
                newInfo.desc = result.desciption
                newInfo.date = (result.date)!
                newInfo.imgSrc = result.imageData as Data?
                menuItems.add(newInfo)
              
                
            }
        }
        
    }
    
   
    func popupNewMemoryView() {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let view = storyboard.instantiateViewController(withIdentifier: "new_note") as? FormMemory_ViewController {
            navigationController?.pushViewController(view, animated: true)
        }
    }

   
    func popupEditMemoryView(itemInfo : MemoryInfo) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let view = storyboard.instantiateViewController(withIdentifier: "edit") as? FormMemory_ViewController {
            view.dataMemory = itemInfo
 
            navigationController?.pushViewController(view, animated: true)
        }
    }

    
    
    func OpenMemoryView(_ itemInfo : MemoryInfo ) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let view = storyboard.instantiateViewController(withIdentifier: "view_memory") as? ViewMemory_ViewController {
            view.itemInfo = itemInfo

            navigationController?.pushViewController(view, animated: true)
            //present(view, animated: true, completion: nil)
        }
    }
    func OpenMapView(_ itemInfo : MemoryInfo ) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let view = storyboard.instantiateViewController(withIdentifier: "view_map") as? locationView {
            view.itemInfo = itemInfo
            
            navigationController?.pushViewController(view, animated: true)
            //present(view, animated: true, completion: nil)
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
  
       
    
        
        return menuItems.count
    }
    

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        //cell.textLabel?.text = self.array[indexPath.row]
            
            let row = indexPath.row
            let data = self.menuItems[ row ] as! MemoryInfo
            var daString = (data.date)!
            // var da = String(describing: daString)
            let formatter = DateFormatter()
            formatter.dateFormat = "dd-MM-yyyy hh:mm a"
            formatter.amSymbol = "AM"
            formatter.pmSymbol = "PM"
            let result = formatter.string(from: daString)
          
            cell.lblTitle.text = data.title
            cell.lblDescription.text = data.desc
            cell.viewDate.text = result
            
            cell.imgView.image = UIImage( data : data.imgSrc!)
            cell.itemInfo = data
            cell.parent = self
            
            if data.check {
                cell.backgroundColor = UIColor.green
            } else {
                cell.backgroundColor = UIColor.white
            }
    
        return cell
    }
        

    @IBAction func unwindToTableView(_ segue : UIStoryboardSegue) {
        
        if let view = segue.source as? FormMemory_ViewController {
            print("unwindToTableView");
            if view.isEditMode == false && view.dataMemory != nil {
                //menuItems.add(view.dataMemory!)
                LoadDatas()
            }
            else if view.isDeleted {
                LoadDatas()
            }
            
            if view.dataMemory != nil {
                self.tableView.reloadData()
            }
        }
        

    }
    

    
}
